Drop the click/tick sound file here as:

    Selected Option.mp3

audio.js loads it from "assets/Selected Option.mp3" and plays it on every
menu snap/confirm. Until it's added, sound playback fails silently and
navigation keeps working normally.
